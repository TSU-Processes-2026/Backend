namespace Application.Auth.Models;

public sealed class UserResponse
{
    public required Guid Id { get; init; }
    public required string Username { get; init; }
}
